create database ems;
use ems;

CREATE TABLE IF NOT EXISTS trainees
(
	id int auto_increment primary key,
	t_last_name varchar(255) DEFAULT NULL,
    t_first_name varchar(255) DEFAULT NULL,
    t_middle_name varchar(255) DEFAULT NULL,
	t_age int(11) DEFAULT NULL,
    strength_average int(11) not NULL,
    trainor varchar(255) DEFAULT NULL
     ) ;
     
     
INSERT INTO trainees(t_last_name, t_first_name, t_middle_name, t_age, strength_average) 
VALUES
	('Vx61A', 'qQIB7', 'OTkmZ', 7, 0),
    ('wYsQ4', '5oQAo', 'nFWyJ', 27, 0)
    ;
	
CREATE TABLE IF NOT EXISTS strengths (

  id int AUTO_INCREMENT primary key,
  computer int(11) default null,
  technical int(11) default null,
  average int(11) not NULL
);

insert into strengths(computer, technical, average)
values
    (62, 62, 0),
    (48, 23, 0)
    ;
    
 
CREATE TABLE IF NOT EXISTS employees
(
	id int auto_increment primary key,
	e_last_name varchar(255) DEFAULT NULL,
    e_first_name varchar(255) DEFAULT NULL,
	e_middle_name varchar(255) DEFAULT NULL,
    e_age int(11) DEFAULT NULL,
    trainee varchar(255) not NULL,
    average int(11) not null,
    attendance int(11) not NULL
    );
    
INSERT INTO employees(e_last_name, e_first_name, e_middle_name, e_age, trainee, average, attendance) 
VALUES
	('7KkTM', 'hGHYx', 'KygYz', 25, '', 0, 0),
    ('bGe5M', 'AaVMt', 'fmFNg', 14, '', 0, 0)
    ;
    
CREATE TABLE IF NOT EXISTS attend(
    id int auto_increment primary key,
    present int(11) not null,
	absent int(11) not null
) ;

insert into attend(present, absent)
Values
	(38, 2),
    (18, 4)
;

#1 GET THE AVERAGE SCORE OF THE TRAINEES IN EACH OF THE STRENGTHS
update trainees set strength_average=
(select sum(computer + technical)/2 from strengths where trainees.id = strengths.id);

#CTRL + ENTER to run
select t_last_name, strength_average from trainees;

#2 GET THE AVERAGE SCORE OF THE TRAINEES TRAINED BY TEACH EMPLOYEE
update employees set trainee=
(select t_last_name from trainees where employees.id = trainees.id);

#CTRL + ENTER to run
select * from employees;
    
#3 GET THE TRAINEES WHOSE STRENGTH IS GREATER THAN THE AVERAGE FOR THAT STRENGTH.

DELIMITER $$
CREATE PROCEDURE gettrainee(IN input INT, OUT OUTPUT VARCHAR(255))
BEGIN
	select t_last_name, t_first_name, t_middle_name, strength_average from trainees where strength_average > input;
END$$
DELIMITER ;

 #CTRL + ENTER to run
call gettrainee (50, @ems);

#4 GET THE EMPLOYEE AND THE TOTAL NUMBER OF ABSENCES OF THEIR TRAINEES

update employees set attendance=
(select absent from attend where employees.id = attend.id);

#CTRL + ENTER to run
select * from employees;

#5 GET THE EMPLOYEE WHOSE ALL TRAINEES ACHIEVE AVERAGE STRENGTH GREATER THAN THE PARAMETER


update employees set average=
(select strength_average from trainees where employees.id = trainees.id);

#CTRL + ENTER to run
select * from employees;

DELIMITER $$
CREATE PROCEDURE getemployee(IN input INT, OUT OUTPUT VARCHAR(255))
BEGIN
	select e_last_name, e_first_name, e_middle_name, trainee, average from employees where average > input;
END$$
DELIMITER ;
 #CTRL + ENTER to run
call getemployee (50, @employee);